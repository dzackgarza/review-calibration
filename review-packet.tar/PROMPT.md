# Review focus: lattice spike calibration slice
