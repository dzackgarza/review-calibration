# Synthetic lattice model (abbreviated)
